
/**
 * @constructor
 */
var {NAME_UPPER} = function() {



};



Librairie{NAMESPACE_POINT}.{NAME_UPPER} = new {NAME_UPPER}();