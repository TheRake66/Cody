<?php

namespace Librairie{NAMESPACE};



class {NAME_UPPER} {

    /**
     * Constructeur
     */
    function __construct() {
    }
   

    /**
     * Destructeur
     */
    function __destruct() {
    }
    
}

?>