<?php
use Librairie\MySQL;

/**
 * Configure la connexion MySQL
 */
MySQL::configure(
	'root',
	'',
	'localhost',
	'codyphp',
);

?>