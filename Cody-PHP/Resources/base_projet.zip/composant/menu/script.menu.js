
class Menu {

    /**
     * Constructeur
     */
    constructor() {
    }

}