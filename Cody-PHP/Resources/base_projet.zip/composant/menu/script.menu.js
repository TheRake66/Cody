/**
 * @constructor
 */
var Menu = function() {

};



Menu = new Menu();