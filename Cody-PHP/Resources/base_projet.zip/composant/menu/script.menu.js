/**
 * @constructor
 */
var Menu = function() {

};



Script.Menu = new Menu();