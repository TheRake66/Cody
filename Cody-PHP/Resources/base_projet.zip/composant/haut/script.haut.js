
class Haut {

    /**
     * Constructeur
     */
    constructor() {
    }

}