/**
 * @constructor
 */
var Haut = function() {

};



Haut = new Haut();