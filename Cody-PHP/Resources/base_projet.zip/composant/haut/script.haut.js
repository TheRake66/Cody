/**
 * @constructor
 */
var Haut = function() {

};



Script.Haut = new Haut();