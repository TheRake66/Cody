/**
 * @constructor
 */
var Panneau = function() {

};



Script.Panneau = new Panneau();