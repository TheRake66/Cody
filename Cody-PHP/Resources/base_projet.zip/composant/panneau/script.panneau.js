
class Panneau {

    /**
     * Constructeur
     */
    constructor() {
    }

}