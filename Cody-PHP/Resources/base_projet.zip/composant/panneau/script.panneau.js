/**
 * @constructor
 */
var Panneau = function() {

};



Panneau = new Panneau();