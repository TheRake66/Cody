
class Bas {

    /**
     * Constructeur
     */
    constructor() {
    }

}