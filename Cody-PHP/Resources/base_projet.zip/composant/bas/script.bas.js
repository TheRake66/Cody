/**
 * @constructor
 */
var Bas = function() {

};



Script.Bas = new Bas();