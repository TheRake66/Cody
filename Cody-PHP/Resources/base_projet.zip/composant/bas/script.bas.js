/**
 * @constructor
 */
var Bas = function() {

};



Bas = new Bas();