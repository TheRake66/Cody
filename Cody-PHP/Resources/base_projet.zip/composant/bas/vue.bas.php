<!-- ================================================== -->
<!-- Creation du footer -->
<footer>
	<span>Crée par Thibault BUSTOS (TheRake66)</span>
</footer>
<!-- ================================================== -->



<!-- ================================================== -->
<!-- Inclusion des fichiers -->
<link rel="stylesheet/less" type="text/css" href="composant/bas/style.bas.less">
<script type='text/javascript' src='composant/bas/script.bas.js'></script>
<!-- ================================================== -->
