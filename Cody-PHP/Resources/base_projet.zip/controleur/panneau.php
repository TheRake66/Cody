<?php

namespace Controleur;



class Panneau {

    /**
     * Constructeur
     */
    function __construct() {
    }


    /**
     * Destructeur
     */
    function __destruct() {
        require_once 'vue/panneau.php';
    }

}

?>