<?php

// ####################################################################################################
// Footer present dans bas.php
$footer = new Formulaire('post', 'index.php', 'fFooter', 'fFooter');
$footer->label('Crée par Thibault BUSTOS (TheRake66)');
$footer->build();
// ####################################################################################################