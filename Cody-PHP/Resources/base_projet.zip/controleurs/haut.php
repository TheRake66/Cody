<?php

namespace Controleur;



class Haut {

    /*
     * Constructeur
     */
    function __construct() {
    }


    /*
     * Destructeur
     */
    function __destruct() {
        require_once '././vues/haut.php';
    }

}

?>