<footer>

	<?php $footer->print(); ?>

	<link rel='stylesheet' href='./styles/bas.css'>
	<script type='text/javascript' src='./scripts/bas.js'></script>

</footer>
