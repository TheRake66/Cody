<?php require_once 'haut.php'; ?>

<main>
	
	<?php $accueil->print(); ?>

	<link rel='stylesheet' href='./styles/styleAccueil.css'>
	<script type='text/javascript' src='./scripts/scriptAccueil.js'></script>

</main>

<?php require_once 'bas.php'; ?>