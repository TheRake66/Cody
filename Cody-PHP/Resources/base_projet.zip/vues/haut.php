<header>

	<?php $header->print(); ?>

	<?php $nav->print(); ?>

	<link rel='stylesheet' href='./styles/haut.css'>
	<script type='text/javascript' src='./scripts/haut.js'></script>
	
</header>