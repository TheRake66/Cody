<!-- ================================================== -->
<!-- Creation du header -->
<header>
	<img src="./images/logo.png">
	<span>Bienvenue dans Cody-PHP</span>
</header>
<!-- ================================================== -->



<!-- ================================================== -->
<!-- Inclusion des fichiers -->
<link rel="stylesheet/less" type="text/css" href="./styles/haut.less">
<script src="https://cdn.jsdelivr.net/npm/less@4.1.1" ></script>
<script type='text/javascript' src='./scripts/haut.js'></script>
<!-- ================================================== -->