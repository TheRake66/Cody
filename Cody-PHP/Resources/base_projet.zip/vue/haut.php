<!-- ================================================== -->
<!-- Creation du header -->
<header>
	<img src="./image/logo.png">
	<span>Bienvenue dans Cody-PHP</span>
</header>
<!-- ================================================== -->



<!-- ================================================== -->
<!-- Inclusion des fichiers -->
<link rel="stylesheet/less" type="text/css" href="style/haut.less">
<script type='text/javascript' src='script/haut.js'></script>
<!-- ================================================== -->