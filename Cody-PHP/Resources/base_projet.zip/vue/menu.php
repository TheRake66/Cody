<!-- ================================================== -->
<!-- Creation du nav -->
<nav>
</nav>
<!-- ================================================== -->



<!-- ================================================== -->
<!-- Inclusion des fichiers -->
<link rel="stylesheet/less" type="text/css" href="./style/menu.less">
<script src="https://cdn.jsdelivr.net/npm/less@4.1.1" ></script>
<script type='text/javascript' src='./script/menu.js'></script>
<!-- ================================================== -->
