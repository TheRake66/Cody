<!-- ================================================== -->
<!-- Creation du aside -->
<aside>
</aside>
<!-- ================================================== -->



<!-- ================================================== -->
<!-- Inclusion des fichiers -->
<link rel="stylesheet/less" type="text/css" href="./style/panneau.less">
<script src="https://cdn.jsdelivr.net/npm/less@4.1.1" ></script>
<script type='text/javascript' src='./script/panneau.js'></script>
<!-- ================================================== -->
