<!-- ================================================== -->
<!-- Creation du aside -->
<aside>
</aside>
<!-- ================================================== -->



<!-- ================================================== -->
<!-- Inclusion des fichiers -->
<link rel="stylesheet/less" type="text/css" href="style/panneau.less">
<script type='text/javascript' src='script/panneau.js'></script>
<!-- ================================================== -->
