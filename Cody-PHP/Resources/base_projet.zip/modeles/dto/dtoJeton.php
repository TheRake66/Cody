<?php

namespace Modele;
use Modele\Reflect\Hydrate;



class Jeton {

    use Hydrate;
	public $numUtilisateur;
	public $valeur;
	public $dateExpiration;

}

?>