<?php

namespace Controleur;



class {NAME_UPPER} {

    /**
     * Constructeur
     */
    function __construct() {
    }


    /**
     * Destructeur
     */
    function __destruct() {
        require_once '././vue/{NAME_LOWER}.php';
    }

}

?>