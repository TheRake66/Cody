<?php

namespace Controleur{NAMESPACE};



class {NAME_UPPER} {

    /**
     * Constructeur
     */
    function __construct() {
    }


    /**
     * Destructeur
     */
    function __destruct() {
        require_once 'vue/{PATH}.php';
    }

}

?>