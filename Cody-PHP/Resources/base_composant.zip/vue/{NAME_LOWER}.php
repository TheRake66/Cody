<!-- ================================================== -->
<!-- Creation du main {NAME_LOWER} -->
<main>
</main>
<!-- ================================================== -->



<!-- ================================================== -->
<!-- Inclusion des fichiers -->
<link rel="stylesheet/less" type="text/css" href="style/{PATH}{NAME_LOWER}.less">
<script type='text/javascript' src='script/{PATH}{NAME_LOWER}.js'></script>
<!-- ================================================== -->
