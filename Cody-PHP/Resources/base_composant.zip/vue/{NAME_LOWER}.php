<!-- ================================================== -->
<!-- Creation du main {NAME_LOWER} -->
<main>
</main>
<!-- ================================================== -->



<!-- ================================================== -->
<!-- Inclusion des fichiers -->
<link rel="stylesheet/less" type="text/css" href="style/{PATH}.less">
<script type='text/javascript' src='script/{PATH}.js'></script>
<!-- ================================================== -->
