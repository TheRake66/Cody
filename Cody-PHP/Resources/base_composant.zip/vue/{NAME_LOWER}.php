<!-- ================================================== -->
<!-- Creation du main {NAME_LOWER} -->
<main>
</main>
<!-- ================================================== -->



<!-- ================================================== -->
<!-- Inclusion des fichiers -->
<link rel="stylesheet/less" type="text/css" href="style/{NAME_LOWER}.less">
<script src="https://cdn.jsdelivr.net/npm/less@4.1.1" ></script>
<script type='text/javascript' src='script/{NAME_LOWER}.js'></script>
<!-- ================================================== -->
