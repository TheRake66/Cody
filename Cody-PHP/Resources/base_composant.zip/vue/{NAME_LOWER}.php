<!-- ================================================== -->
<!-- Creation du main {NAME_UPPER} -->
<main>
</main>
<!-- ================================================== -->



<!-- ================================================== -->
<!-- Inclusion des fichiers -->
<link rel="stylesheet/less" type="text/css" href="style/{PATH}.less">
<script type='text/javascript' src='script/{PATH}.js'></script>
<!-- ================================================== -->
