/**
 * @constructor
 */
var {NAME_UPPER} = function() {

};



Script{NAMESPACE_POINT}.{NAME_UPPER} = new {NAME_UPPER}();