/**
 * @constructor
 */
var {NAME_UPPER} = function() {

};



{NAME_UPPER} = new {NAME_UPPER}();