<!-- ================================================== -->
<!-- Creation de la page {NAME_LOWER} -->
<main>
</main>
<!-- ================================================== -->



<!-- ================================================== -->
<!-- Inclusion des fichiers -->
<link rel="stylesheet/less" type="text/css" href="./styles/{NAME_LOWER}.less">
<script src="https://cdn.jsdelivr.net/npm/less@4.1.1" ></script>
<script type='text/javascript' src='./scripts/{NAME_LOWER}.js'></script>
<!-- ================================================== -->
