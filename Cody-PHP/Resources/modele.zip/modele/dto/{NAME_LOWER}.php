<?php

namespace Modele\dto;
use Modele\Reflect\Hydrate;



class {NAME_UPPER} {

    use Hydrate;
	public $id{NAME_UPPER};
	
}

?>