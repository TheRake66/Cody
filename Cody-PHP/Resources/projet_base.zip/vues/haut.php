<header>

	<link rel="stylesheet" href="./styles/haut.css">
	<script type="text/javascript" src="./scripts/haut.js"></script>

	<?php $formHeader->afficherFormulaire(); ?>

	<nav>
		<?php $menuNav->afficherFormulaire(); ?>
	</nav>
	
</header>