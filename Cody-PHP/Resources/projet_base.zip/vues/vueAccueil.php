<link rel="stylesheet" href="./styles/styleAccueil.css">
<script type="text/javascript" src="./scripts/scriptAccueil.js"></script>

<?php require_once 'haut.php'; ?>

<main>
	<?php $accueil->afficherFormulaire(); ?>
</main>

<?php require_once 'bas.php'; ?>