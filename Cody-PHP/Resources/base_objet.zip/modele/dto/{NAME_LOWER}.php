<?php

namespace Modele\dto{NAMESPACE};
use Modele\Reflect\Hydrate;



class {NAME_UPPER} {

    use Hydrate;
	public $id{NAME_UPPER};
	
}

?>