<?php
namespace Librairy;



// Librairie Msgbox
class Msgbox {

    /**
     * Les images
     */
    const IMG_OK = 'ok';
    const IMG_WARN = 'warn';
    const IMG_INFO = 'info';
    const IMG_ERROR = 'error';


    /**
     * Affiche une messagebox
     *
     * @param string le titre de la msgbox
     * @param string le contenu de la msgbox
     * @param string l'image de la msgbox
     * @param string le html
     */
    static function show($titre, $content, $level = Msgbox::IMG_OK) {
        $level = 'src="assets/img/' . Theme::get() . '/msgbox/' . $level . '.svg"';
        return '<msgbox>
                <div>		
                    <h1>' . $titre . '</h1>
                    <article>
                        <img' . $level . ' alt="Msgbox">
                        <p>' . $content . '</p>
                    </article>
                    <div>
                        <button onclick="this.parentNode.parentNode.parentNode.remove();">Ok</button>
                    </div>
                </div>
            </msgbox>';
    }
    
}

?>