
class Notfound {

    /**
     * Constructeur
     */
    constructor() {
		
    }

}

let notfound = new Notfound();