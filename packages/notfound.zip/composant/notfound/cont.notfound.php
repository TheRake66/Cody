<?php

namespace Controleur;
use Kernel\Url;



class Notfound {

    /**
     * Constructeur
     */
    function __construct() {
        http_response_code(404);
        require_once 'composant/notfound/vue.notfound.php';
    }


    /**
     * Redirige vers le 404
     */
    public static function notFound() {
		Url::go('404');
    }


    /**
     * Verifi une condition, si faux on renvoi vers le 404
     * 
     * @param bool condition, exemple: Notfound::checkFound($user = getUsers());
     */
    public static function checkFound($if) {
        if (is_null($if) || !$if) {
            self::notFound();
        }
    }
    
}

?>