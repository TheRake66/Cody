<?php

namespace Controleur;



class Notfound {

    /**
     * Constructeur
     */
    function __construct() {
    }


    /**
     * Destructeur
     */
    function __destruct() {
        http_response_code(404);
        require_once 'composant/notfound/vue.notfound.php';
    }


    /**
     * Redirige vers le 404
     */
    public static function notFound() {
        echo '<script type="text/javascript">window.location = "?redirect=404"</script>';
        exit;
    }


    /**
     * Verifi une condition, si faux on renvoi vers le 404
     * 
     * @param bool condition, exemple: Notfound::checkFound($user = getUsers());
     */
    public static function checkFound($if) {
        if (is_null($if) || !$if) {
            self::notFound();
        }
    }
    
}

?>