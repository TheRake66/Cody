<!-- ================================================== -->
<!-- Creation de la page Notfound -->

<main>
    
    <h1>Erreur 404</h1>
    <p>Page non trouvée</p>

</main>

<!-- ================================================== -->



<!-- ================================================== -->
<!-- Inclusion des fichiers -->
<link rel="stylesheet/less" type="text/css" href="composant/notfound/style.notfound.less">
<script type='text/javascript' src='composant/notfound/script.notfound.js'></script>
<!-- ================================================== -->
