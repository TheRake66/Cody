<?php
use Kernel\Html;
use Kernel\Convert;
use Kernel\Url;
?>



<!-- Vue du composant Notfound  -->
<notfound>
    <h1>Erreur 404</h1>
    <p>Page non trouvée</p>
</notfound>