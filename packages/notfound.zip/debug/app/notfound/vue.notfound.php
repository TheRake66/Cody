<?php
use Kernel\Html;
use Kernel\Convert;
use Kernel\Url;
?>



<!-- 
Vue du composant Notfound
Author: Thibault BUSTOS (TheRake66)
Version: 1.0
Category: Package
Copyright: © 2022 - Thibault BUSTOS (TheRake66)
 -->
<notfound>
    <h1>Erreur 404</h1>
    <p>Page non trouvée</p>
</notfound>