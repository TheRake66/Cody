import Html from '{BACK_PATH}../../../.kernel/js/html.js';
import Rest from '{BACK_PATH}../../../.kernel/js/rest.js';
import Url from '{BACK_PATH}../../../.kernel/js/url.js';



/**
 * Script du composant Notfound
 */
export default class Notfound {

    /**
     * Constructeur
     */
    constructor() {
		
    }

}