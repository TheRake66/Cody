
/**
 * Script du composant Notfound
 * 
 * @author Thibault Bustos (TheRake66)
 * @version 1.0
 * @category Package
 * @license MIT License
 * @copyright © 2022 - Thibault BUSTOS (TheRake66)
 */
export default class Notfound {

    /**
     * Constructeur
     */
    constructor() {
		
    }

}