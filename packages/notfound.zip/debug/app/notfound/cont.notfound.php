<?php
namespace Controler;
use Kernel\Rest;
use Kernel\DataBase;
use Kernel\Render;
use Kernel\Url;



/**
 * Controleur du composant Notfound
 */
class Notfound extends Render {

    /**
     * Constructeur
     */
    function __construct() {
        http_response_code(404);
        // Rendu de la vue
		$this->view();
    }


    /**
     * Redirige vers le 404
     * 
     * @return void
     */
    public static function notFound() {
		Url::go('404');
    }


    /**
     * Verifi une condition, si faux on renvoi vers le 404
     * 
     * @param bool condition, exemple: Notfound::checkFound($user = getUsers());
     * @return void
     */
    public static function checkFound($if) {
        if (is_null($if) || !$if) {
            self::notFound();
        }
    }
    
}

?>