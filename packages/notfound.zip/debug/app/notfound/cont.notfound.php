<?php
namespace Controler;
use Kernel\Rest;
use Kernel\DataBase;
use Kernel\Render;



/**
 * Controleur du composant Notfound
 */
class Notfound {

    /**
     * Constructeur
     */
    function __construct() {
        http_response_code(404);
        // Rendu de la vue
		Render::view();
    }


    /**
     * Redirige vers le 404
     */
    public static function notFound() {
		Url::go('404');
    }


    /**
     * Verifi une condition, si faux on renvoi vers le 404
     * 
     * @param bool condition, exemple: Notfound::checkFound($user = getUsers());
     */
    public static function checkFound($if) {
        if (is_null($if) || !$if) {
            self::notFound();
        }
    }
    
}

?>