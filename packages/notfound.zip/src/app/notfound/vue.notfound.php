<!-- Creation de la page Denied -->
<?php
use Kernel\Html;
use Kernel\Url;
use Kernel\Convert;
?>



<main>
    <h1>Erreur 404</h1>
    <p>Page non trouvée</p>
</main>