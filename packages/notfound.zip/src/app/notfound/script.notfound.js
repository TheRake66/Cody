// Ajout du script de la page Notfound
class Notfound {

    /**
     * Constructeur
     */
    constructor() {
		
    }

}