<?php
namespace Controler;
use Kernel\Render;
use Kernel\Ajax;



// Controleur de la page Progress_circle
class Progress_circle extends Render {

    /**
     * Id de la barre
     */
    protected $id;

    /**
     * Pourcentage de la barre
     */
    protected $percent;

    /**
     * Couleur de la barre
     */
    protected $color;

    /**
     * Taille de la barre
     */
    protected $size;

    /**
     * Taille de la police de la barre
     */
    protected $font;

    /**
     * Taille de la bordure de la barre
     */
    protected $border;

    /**
     * Unite de mesure de la barre
     */
    protected $unite;


    /**
     * Constructeur
     * 
     * @param int id
     * @param double pourcentage
     * @param string couleur
     * @param int taille en diametre
     * @param int taille de la police
     * @param int taille de la bordure
     * @param string unite de style
     */
    function __construct($id, $percent, $color = 'green', $size = 250, $font = 72, $border = 5, $unite = 'px') {

        if ($percent > 100) $percent = '+100';

        $this->id = $id;
        $this->percent = $percent;
        $this->color = $color;
        $this->size = $size;
        $this->font = $font;
        $this->border = $border;
        $this->unite = $unite;
		
        // Rendu de la vue
		$this->view();
    }
	
}

?>