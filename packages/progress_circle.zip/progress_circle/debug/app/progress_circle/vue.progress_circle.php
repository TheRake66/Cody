<!-- Creation de la page Progress_circle -->
<?php
use Kernel\Html;
use Kernel\Url;
use Kernel\Convert;
?>



<div <?= 'id="' . $this->id . '"' ?> <?= 
'class="div-progress-' . $this->color . '"
style="
--percent: ' . (110 - $this->percent) . '%; 
--font: ' . $this->font . $this->unite . '; 
--size: ' . $this->size . $this->unite . ';
--border: ' . $this->border . $this->unite . ';
"'?>><h1><?= $this->percent ?>%</h1></div>