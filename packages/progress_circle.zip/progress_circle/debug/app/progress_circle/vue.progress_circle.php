<?php
use Kernel\Html;
use Kernel\Convert;
use Kernel\Url;
?>



<!-- Vue du composant Progress_circle  -->
<progress_circle <?= 'id="' . $id . '"' ?> <?= 
'class="div-progress-' . $color . '"
style="
--percent: ' . (110 - $percent) . '%; 
--font: ' . $font . $unite . '; 
--size: ' . $size . $unite . ';
--border: ' . $border . $unite . ';
"'?>>
    <h1><?= $percent ?>%</h1>
</progress_circle>