import Html from '{BACK_PATH}../../../.kernel/js/html.js';
import Rest from '{BACK_PATH}../../../.kernel/js/rest.js';
import Url from '{BACK_PATH}../../../.kernel/js/url.js';



/**
 * Script du composant Progress_circle
 */
export default class Progress_circle {

    /**
     * Constructeur
     */
    constructor() {
		
    }

}