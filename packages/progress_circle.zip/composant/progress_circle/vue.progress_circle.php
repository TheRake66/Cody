<!-- Creation de la page Progress_circle -->
<div <?= 'id="' . $this->id . '"' ?> <?= 
'class="div-progress-' . $this->color . '"
style="
--percent: ' . (110 - $this->percent) . '%; 
--font: ' . $this->font . $this->unite . '; 
--size: ' . $this->size . $this->unite . ';
--border: ' . $this->border . $this->unite . ';
"'?>><h1><?= $this->percent ?>%</h1></div>



<!-- Inclusion des fichiers -->
<link rel="stylesheet/less" type="text/css" href="composant/progress_circle/style.progress_circle.less">
<script type='text/javascript' src='composant/progress_circle/script.progress_circle.js'></script>
