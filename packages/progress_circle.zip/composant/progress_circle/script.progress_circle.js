
class Progress_circle {

    /**
     * Constructeur
     */
    constructor() {
		
    }

}

let progress_circle = new Progress_circle();