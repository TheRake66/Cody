<?php
namespace Controller;
use Kernel\IO\Render;



/**
 * Controleur du composant Progress_circle
 *
 * @author Thibault Bustos (TheRake66)
 * @version 1.0
 * @package Controller
 * @category Package
 * @license MIT License
 * @copyright © 2022 - Thibault BUSTOS (TheRake66)
 */
class Progress_circle extends Render {

    /**
     * Constructeur
     * 
     * @param int id
     * @param double pourcentage
     * @param string couleur
     * @param int taille en diametre
     * @param int taille de la police
     * @param int taille de la bordure
     * @param string unite de style
     */
    function __construct($id, $percent, $color = 'green', $size = 250, $font = 72, $border = 5, $unite = 'px') {

        if ($percent > 100) $percent = '+100';
		
        // Rendu de la vue
		$this->renderComponent([
            'id' => $id,
            'percent' => $percent,
            'color' => $color,
            'size' => $size,
            'font' => $font,
            'border' => $border,
            'unite' => $unite
        ]);
    }
	
}

?>