<?php
use Kernel\HTML\Attribute;
?>



<!-- 
Vue du composant Progress_circle
Author: Thibault Bustos (TheRake66)
Version: 1.0
Categorie: Package
Copyright: © 2022 - Thibault BUSTOS (TheRake66)
 -->
<progress_circle <?= Attribute::id($id) ?>
    <?= Attribute::style([
        '--percent' => (110 - $percent) . '%',
        '--percent' => (110 - $percent) . '%;',
        '--font' => $font . $unite,
        '--size' => $size . $unite,
        '--border' => $border . $unite
    ]) ?>>
    <h1><?= $percent ?>%</h1>
</progress_circle>