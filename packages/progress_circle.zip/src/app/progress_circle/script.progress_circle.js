// Ajout du script de la page Progress_circle
class Progress_circle {

    /**
     * Constructeur
     */
    constructor() {
		
    }

}