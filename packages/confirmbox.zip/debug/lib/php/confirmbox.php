<?php
namespace Library;



/**
 * Librairie Confirmbox.
 * 
 * @author thiba
 * @version 1.0
 * @package Library
 * @category Librairie
 */
class Confirmbox {

    /**
     * Point d'entrée de la librairie.
     * 
     * @access public
     * @return void
     */
    function __construct() {

    }
    
}

?>