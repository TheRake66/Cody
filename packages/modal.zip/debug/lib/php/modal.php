<?php
namespace Librairy;



/**
 * Librairie Modal
 */
class Modal {

    /**
     * Constructeur
     */
    function __construct() {

    }
    
}

?>