<?php
namespace Library;
use Kernel\Html\Attribute;



/**
 * Librairie Theme
 *
 * @author Thibault Bustos (TheRake66)
 * @version 1.0
 * @package Librairy
 * @category Package
 * @license MIT License
 * @copyright © 2022 - Thibault BUSTOS (TheRake66)
 */
class Theme {

    /**
     * Theme par defaut
     */
    const DEFAULT_THEME = 'light';
    

    /**
     * Defini un theme par defaut + defini le theme
     * 
     * @return string l'attribut html
     */
    static function init() {
        if (!isset($_SESSION['theme'])) {
            self::set(self::DEFAULT_THEME);
        }
        return Attribute::set(self::get(), 'data-theme');
    }


    /**
     * Change le theme
     * 
     * @param string le theme
     */
    static function set($theme) {
        $_SESSION['theme'] = $theme;
    }
    

    /**
     * Retourne le theme actuel
     * 
     * @return string le theme
     */
    static function get() {
        return $_SESSION['theme'];
    }


    /**
     * Retourne une image du theme actuel
     * 
     * @param string le nom de l'image
     * @return string le chemin
     */
    static function image($name) {
        return 'assets/img/' . self::get() . '/' . $name;
    }


    /**
     * Retourne une image du theme actuel dans une src
     * 
     * @param string le nom de l'image
     * @param string le texte alt
     * @return string la src
     */
    static function imageSrc($name, $alt = null) {
        return Attribute::src('assets/img/' . self::get() . '/' . $name, $alt ?? $name);
    }
    
}

?>