<?php
// Librairie Theme
namespace Librairie;
use Kernel\Html;



class Theme {

    /**
     * Theme par defaut
     */
    const DEFAULT_THEME = 'dark';

    
    /**
     * Defini un theme par defaut + defini le theme
     * 
     * @return string l'attribut html
     */
    static function init() {
        if (!isset($_SESSION['theme'])) {
            self::set(self::DEFAULT_THEME);
        }
        return Html::setAttrib(self::get(), 'data-theme');
    }


    /**
     * Change le theme
     * 
     * @param string le theme
     */
    static function set($theme) {
        $_SESSION['theme'] = $theme;
    }
    

    /**
     * Retourne le theme actuel
     * 
     * @return string le theme
     */
    static function get() {
        return $_SESSION['theme'];
    }


    /**
     * Retourne le dossier image du theme actuel en src
     * 
     * @param string le nom de l'image
     * @return string le src
     */
    static function image($name) {
        return Html::setAttrib('image/' . self::get() . '/' . $name, 'src');
    }
    
}

?>