<?php
namespace Controler;
use Kernel\Render;



/**
 * Controleur du composant Code_pan
 */
class Code_pan extends Render {

    /**
     * Constructeur
     * 
     * @param string le code a affiche
     * @param int le nombre de ligne
     * @param string le language pour la coloration
     */
    function __construct($code, $lenght, $lang) {
        // Rendu de la vue
        $this->view([
            'code' => $code, 
            'lenght' => $lenght,
            'lang' => $lang
        ]);
    }


    /**
     * Affiche un code via un string
     * 
     * @param string le code a affiche
     * @param string le language pour la coloration
     * @param int la taille de l'indentation
     * @param int la ligne de debut
     * @param int la ligne de fin
     */
    static function fromString($code, $lang = 'python', $indentSize = 4, $start = 0, $end = null) {
        $clear = self::clearCode($code, $indentSize, $start, $end);
        new Code_pan($clear[0], $clear[1], $lang);
    }


    /**
     * Affiche un code via un fichier
     * 
     * @param string le code a affiche
     * @param string le language pour la coloration
     * @param int la taille de l'indentation
     * @param int la ligne de debut
     * @param int la ligne de fin
     */
    static function fromFile($file, $lang = 'python', $indentSize = 4, $start = 0, $end = null) {
        if (is_file($file) && is_readable($file)) {
            $code = file_get_contents($file);
            $clear = self::clearCode($code, $indentSize, $start, $end);
            new Code_pan($clear[0], $clear[1], $lang);
        } else {
            new Code_pan('Impossible de lire le fichier', 0, $lang);
        }
    }


    /**
     * Nettoie un code (indentation, ligne de fin vide etc...)
     * 
     * @param string le code a affiche
     * @param int la taille de l'indentation
     * @param int la ligne de debut
     * @param int la ligne de fin
     * @return array le code nettoye et son nombre de ligne
     */
    static function clearCode($code, $indentSize = 4, $start = 0, $end = null) {
        $lines = explode(PHP_EOL, $code);
        $count = 0;
        $added = 0;
        $tocut = 0;
        $arr = [];
        $indent = str_repeat(' ', $indentSize);
        foreach ($lines as $l) {
            $count++;
            // Si dans limites
            if ($count >= $start && (is_null($end) || $count < $end)) {
                $added++;
                $r = rtrim($l);
                
                // Indentation
                if ($added == 1) {
                    $tocut = $indentSize * substr_count($r, $indent);
                }
                $arr[] = substr($r, $tocut);
            }
        }
        // Supprime les premieres lignes vide
        for ($i = 0; $i < count($arr) - 1; $i++) {
            if (empty(trim($arr[$i]))) {
                unset($arr[$i]);
                $added -= 1;
            } else {
                break;
            }
        }
        // Supprime les dernieres lignes vide
        for ($i = count($arr) - 1; $i >= 0; $i--) {
            if (empty(trim($arr[$i]))) {
                unset($arr[$i]);
                $added -= 1;
            } else {
                break;
            }
        }
        return [ implode(PHP_EOL, $arr), $added ];
    }

}

?>