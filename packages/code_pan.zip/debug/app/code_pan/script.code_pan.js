import Find from '../../../.kernel/js/html/find.js';
import Export from '../../../.kernel/js/io/export.js';



/**
 * Script du composant Code_pan
 * 
 * @author Thibault Bustos (TheRake66)
 * @version 1.0
 * @category Package
 * @license MIT License
 * @copyright © 2022 - Thibault BUSTOS (TheRake66)
 */
export default class Code_pan {

    /**
     * Ouvre le code dans un nouvel onglet
     * 
     * @param {Element} ele button cliquer
     */
    fullScreen(ele) {
        let text = Find.queryAll('code', ele.parentNode.parentNode)[0].textContent;
        Export.fullScreen(text
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;"));
    }
    
}