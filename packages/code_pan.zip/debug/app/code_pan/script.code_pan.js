import Html from '../../../.kernel/js/html.js';
import Rest from '../../../.kernel/js/rest.js';
import Url from '../../../.kernel/js/url.js';
import Html from '../../../.kernel/js/html.js';
import Export from '../../../.kernel/js/export.js';



/**
 * Script du composant Code_pan
 */
export default class Code_pan {

    /**
     * Ouvre le code dans un nouvel onglet
     * 
     * @param {Element} ele button cliquer
     */
    fullScreen(ele) {
        let text = Html.queryAll('code', ele.parentNode.parentNode)[0].textContent;
        Export.fullScreen(
            text.replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;"));
    }
    
}