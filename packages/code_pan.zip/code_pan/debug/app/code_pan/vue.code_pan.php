<!-- Creation de la page Code_pan -->
<?php 
use Kernel\Html;
use Kernel\Url;
use Kernel\Convert;
?>



<div class="code_pan">
	<div class="code_pan_head">
		<span><?= ucfirst($lang) ?></span>
		<button onclick="code_pan.fullScreen(this);">
			<img src="asset/img/fullscreen.svg" alt="Full">Plein écran
		</button>
	</div>
	<div class="code_pan_cont">
		<div class="code_pan_num">
			<?php for ($i = 0; $i < $lenght; $i++): ?>
				<span><?= $i ?></span>
			<?php endfor; ?>
		</div>
		<pre class="code_pan_code"><code <?= Html::setAttrib($lang, 'class') ?>><?= empty($code) ? ' ' : htmlspecialchars($code) ?></code></pre>
	</div>
</div>