// Ajout de script de la page Code_pan
export default class Code_pan {

    /**
     * Ouvre le code dans un nouvel onglet
     * 
     * @param {Element} ele button cliquer
     */
    fullScreen(ele) {
        let text = ele.parentNode.parentNode.querySelectorAll('code')[0].textContent;
        let tab = window.open('about:blank', '_blank');
        tab.document.write(
            '<pre>' + 
                text.replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;") + 
            '</pre>');
        tab.document.close();
    }
    
}