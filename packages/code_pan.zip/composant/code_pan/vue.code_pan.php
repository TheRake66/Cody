<!-- Creation de la page Code_pan -->
<?php 
use Kernel\Html;
use Kernel\Url;
use Kernel\Convert;
?>

<div class="code_pan">
	<div class="code_pan_head">
		<span><?= ucfirst($this->lang) ?></span>
		<button onclick="code_pan.fullScreen(this);">
			<img src="image/icons8-plein-écran.svg" alt="Full">Plein écran
		</button>
	</div>
	<div class="code_pan_cont">
		<div class="code_pan_num">
			<?php for ($i = 0; $i < $this->lenght; $i++): ?>
				<span><?= $i ?></span>
			<?php endfor; ?>
		</div>
		<pre><code <?= Html::setAttrib($this->lang, 'class') ?>><?= empty($this->code) ? ' ' : htmlspecialchars($this->code) ?></code></pre>
	</div>
</div>


<!-- Inclusion des fichiers -->
<link rel="stylesheet/less" type="text/css" href="composant/code_pan/style.code_pan.less">
<script type='text/javascript' src='composant/code_pan/script.code_pan.js'></script>
