

/**
 * Script du composant Denied
 */
export default class Denied {

    /**
     * Constructeur
     */
    constructor() {
		
    }

}