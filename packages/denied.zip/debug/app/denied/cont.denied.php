<?php
namespace Controler;
use Kernel\Database\Factory\Crud;
use Kernel\Url;
use Kernel\Router;
use Kernel\Render;
use Kernel\Session\User;
use Modele\dto\Utilisateur;



/**
 * Controleur du composant Denied
 */
class Denied extends Render {

    /**
     * Constructeur
     */
    function __construct() {
        http_response_code(403);
        // Rendu de la vue
		$this->view();
    }


    /**
     * Verifi les autorisations
     */
    public static function checkAutorize() {
        if (!User::has() && Router::get() != '403') {
            if (!isset($_GET['token']) || !($utilisateur = Crud::read(new Utilisateur($_GET['token']), 'token'))) {
                Url::go('403');
            } else {
                User::set($utilisateur);
            }
        }
		if (isset($_GET['token'])) {
			Url::go('accueil');
		}
    }

}

?>