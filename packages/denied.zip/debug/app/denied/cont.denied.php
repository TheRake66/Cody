<?php
namespace Controller;
use Kernel\Database\Factory\Crud;
use Kernel\URL\Router;
use Kernel\IO\Render;
use Kernel\Session\Token;
use Kernel\Session\User;
use Kernel\URL\Location;
use Modele\DTO\Utilisateur;



/**
 * Controleur du composant Denied
 *
 * @author Thibault Bustos (TheRake66)
 * @version 1.0
 * @package Controller
 * @category Package
 * @license MIT License
 * @copyright © 2022 - Thibault BUSTOS (TheRake66)
 */
class Denied extends Render {

    /**
     * Constructeur
     */
    function __construct() {
        http_response_code(403);
        // Rendu de la vue
		$this->renderComponent();
    }


    /**
     * Verifi les autorisations
     */
    public static function checkAutorize() {
        if (Router::getCurrent() !== '/denied') {
            $token = Token::get() ?? (User::has() ? User::get()->token : null);

            if (!is_null($token) && !empty($token)) {
                $user = new Utilisateur();
                $user->token = $token;
                $user = $user->read('token');

                if ($user && !$user->hasExpired()) {
                    User::set($user);
                } else {
                    Location::go('/denied');
                }
            } else {
                Location::go('/denied');
            }
        }
    }

}

?>