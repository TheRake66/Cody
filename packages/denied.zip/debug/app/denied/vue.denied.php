<?php
use Kernel\Html;
use Kernel\Url;
use Kernel\Convert;
?>



<!-- 
Vue du composant Denied
Author: Thibault Bustos (TheRake66)
Version: 1.0
Categorie: Package
Copyright: © 2022 - Thibault BUSTOS (TheRake66)
 -->
<denied>
    <h1>Erreur 403</h1>
    <p>Accès refusé</p>
</denied>