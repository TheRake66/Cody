<?php
namespace Controller;
use Kernel\Url\Router;
use Kernel\Io\Render;
use Kernel\Session\Token;
use Kernel\Session\User;
use Kernel\Url\Location;
use Modele\Dto\Utilisateur;



/**
 * Controleur du composant Denied
 *
 * @author Thibault Bustos (TheRake66)
 * @version 1.0
 * @package Controller
 * @category Package
 * @license MIT License
 * @copyright © 2022 - Thibault BUSTOS (TheRake66)
 */
class Denied extends Render {

    /**
     * Constructeur
     */
    function __construct() {
        http_response_code(403);
        // Rendu de la vue
		$this->view();
    }


    /**
     * Verifi les autorisations
     */
    public static function check() {
        if (Router::current() !== '/denied') {
            $token = Token::get() ?? (User::has() ? User::get()->token : null);

            if (!is_null($token) && !empty($token)) {
                $user = new Utilisateur();
                $user->token = $token;
                $user = $user->read('token');

                if ($user && !$user->hasExpired()) {
                    User::set($user);
                } else {
                    Location::go('/denied');
                }
            } else {
                Location::go('/denied');
            }
        }
    }

}

?>