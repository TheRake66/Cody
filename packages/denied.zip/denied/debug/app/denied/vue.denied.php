<?php
use Kernel\Html;
use Kernel\Url;
use Kernel\Convert;
?>



<!-- Vue du composant Denied  -->
<denied>
    <h1>Erreur 403</h1>
    <p>Accès refusé</p>
</denied>