// Ajout du script de la page Denied
class Denied {

    /**
     * Constructeur
     */
    constructor() {
		
    }

}