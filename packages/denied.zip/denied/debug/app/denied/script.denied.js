import Html from '../../../.kernel/js/html.js';
import Rest from '../../../.kernel/js/rest.js';
import Url from '../../../.kernel/js/url.js';



/**
 * Script du composant Denied
 */
export default class Denied {

    /**
     * Constructeur
     */
    constructor() {
		
    }

}