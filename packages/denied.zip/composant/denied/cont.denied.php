<?php

namespace Controleur;
use Kernel\Url;
use Kernel\DataBase;
use Kernel\Session;
use Kernel\Router;
use Modele\dto\Utilisateur;



class Denied {

    /**
     * Constructeur
     */
    function __construct() {
        http_response_code(403);
        require_once 'composant/denied/vue.denied.php';
    }


    /**
     * Verifi les autorisations
     */
    public static function checkAutorize() {
        if (!Session::hasSession() && Router::get() != '403') {
            if (!isset($_GET['token']) || !($utilisateur = DataBase::read(new Utilisateur($_GET['token'])))) {
                Url::go('403');
            } else {
                Session::setSession($utilisateur);
            }
        }
    }

}

?>