<?php

namespace Controleur;



class Denied {

    /**
     * Constructeur
     */
    function __construct() {
    }


    /**
     * Destructeur
     */
    function __destruct() {
        http_response_code(403);
        require_once 'composant/denied/vue.denied.php';
    }


    /**
     * Verifi les autorisations
     */
    public static function checkAutorize() {
        if (!isset($_GET['redirect']) || (isset($_GET['redirect']) && $_GET['redirect'] != '403')) {

            if (isset($_GET['token'])) {
                $_SESSION['token'] = $_GET['token'];
            }
    
            if (!isset($_SESSION['token']) || !($_SESSION['user'] = User::getByToken($_SESSION['token']))) {
                echo '<script type="text/javascript">window.location = "?redirect=403"</script>';
            }

            User::setLastConnection($_SESSION['token']);
        }
    }

}

?>