
class Denied {

    /**
     * Constructeur
     */
    constructor() {
		
    }

}

let denied = new Denied();