<!-- Creation de la page Denied -->
<main>
    
    <h1>Erreur 403</h1>
    <p>Accès refusé</p>
	
</main>



<!-- Inclusion des fichiers -->
<link rel="stylesheet/less" type="text/css" href="composant/denied/style.denied.less">
<script type='text/javascript' src='composant/denied/script.denied.js'></script>
