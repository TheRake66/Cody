<?php
namespace Controler;
use Kernel\Url;
use Kernel\DataBase;
use Kernel\Session;
use Kernel\Router;
use Kernel\Render;
use Kernel\Ajax;
use Modele\dto\Utilisateur;



// Controleur de la page Denied
class Denied extends Render {

    /**
     * Constructeur
     */
    function __construct() {
        http_response_code(403);
        // Rendu de la vue
		$this->view();
    }


    /**
     * Verifi les autorisations
     */
    public static function checkAutorize() {
        if (!Session::hasSession() && Router::get() != '403') {
            if (!isset($_GET['token']) || !($utilisateur = DataBase::read(new Utilisateur($_GET['token'])))) {
                Url::go('403');
            } else {
                Session::setSession($utilisateur);
            }
        }
		if (isset($_GET['token'])) {
			Url::go('accueil');
		}
    }

}

?>