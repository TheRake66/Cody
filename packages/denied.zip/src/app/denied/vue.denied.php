<!-- Creation de la page Denied -->
<?php
use Kernel\Html;
use Kernel\Url;
use Kernel\Convert;
?>



<main>
    <h1>Erreur 403</h1>
    <p>Accès refusé</p>
</main>