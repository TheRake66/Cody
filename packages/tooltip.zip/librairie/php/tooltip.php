<?php

namespace Librairie;



class Tooltip {

    /**
     * Creer un div pour le tooltip
     */
    static function begin() {
        echo '<div class="tooltip">';
    }


    /**
     * Creer le tooltip
     * 
     * @param string position du tooltip (top bottom left right)
     * @param string message du tooltip
     * @param string titre du tooltip
     * @param int largeur du tooltip
     * @param string couleur de fond
     * @param string courleur du texte
     */
    static function end($position, $message, $titre = '', $size = 0, $back = 'white', $fore = 'black') {
        echo '  <div class="message ' . $position . '" style="
                    min-width: ' . $size . 'px;
                    --back: ' . $back . ';
                    color: ' . $fore . ';
                    ">
                    <h3><b>' . $titre . '</b></h3>
                    <p>' . $message . '</p>
                    <i></i>
                </div>
            </div>';
    }
    
}

?>