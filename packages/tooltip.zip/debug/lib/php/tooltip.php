<?php
namespace Librairy;



// Librairie Tooltip
class Tooltip {

    /**
     * Creer un div pour le tooltip
     */
    static function begin() {
        return '<tooltip>';
    }


    /**
     * Creer le tooltip
     * 
     * @param string position du tooltip (top bottom left right)
     * @param string message du tooltip
     * @param string titre du tooltip
     * @param int largeur du tooltip
     * @param string couleur de fond
     * @param string courleur du texte
     */
    static function end($position, $message, $titre = '', $size = 0, $back = 'white', $fore = 'black') {
        return '  <tooltip-message class="' . $position . '" style="
                    min-width: ' . $size . 'px;
                    --back: ' . $back . ';
                    color: ' . $fore . ';
                    ">
                    ' . (!empty($titre) ? '<h3><b>' . $titre . '</b></h3>' : '') . '
                    <p>' . $message . '</p>
                    <i></i>
                </tooltip-message>
            </tooltip>';
    }
    
}

?>