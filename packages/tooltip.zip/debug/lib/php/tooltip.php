<?php
namespace Librairy;



// Librairie Tooltip
class Tooltip {

    /**
     * Creer un div pour le tooltip
     * 
     * @param string position du tooltip (top bottom left right)
     * @param string message du tooltip
     * @param string titre du tooltip
     * @param int largeur du tooltip
     * @param string couleur de fond
     * @param string couleur du texte
     * @return string le html
     */
    static function begin($position, $message, $titre = '', $size = 0, $back = 'white', $fore = 'black') {
        return '<tooltip>
                    <tooltip-message class="' . $position . '" style="
                        min-width: ' . $size . 'px;
                        --back: ' . $back . ';
                        color: ' . $fore . ';
                        ">
                        ' . (!empty($titre) ? '<h3><b>' . $titre . '</b></h3>' : '') . '
                        <p>' . $message . '</p>
                        <i></i>
                    </tooltip-message>';
    }


    /**
     * Creer le tooltip
     * 
     * @return string le html
     */
    static function end() {
        return '</tooltip>';
    }
    
}

?>