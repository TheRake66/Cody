<link rel="stylesheet" href="./styles/style{NAME}.css">
<script type="text/javascript" src="./scripts/script{NAME}.js"></script>

<?php require_once 'haut.php'; ?>

<main>
	<?php ${NAME}->afficherFormulaire(); ?>
</main>

<?php require_once 'bas.php'; ?>