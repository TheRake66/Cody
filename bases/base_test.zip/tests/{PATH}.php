<?php
namespace Test{NAMESPACE_SLASH};



// Classe de test Utilisateur
class {NAME_UPPER} {

    /**
     * Lancement des tests
     */
    static function run() {
        
    }

}

?>