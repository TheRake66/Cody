<?php
namespace Test{NAMESPACE_SLASH};
use Kernel\Debug\Unit;



/**
 * Classe de test {NAME_UPPER}
 * 
 * @author {USER_NAME}
 * @version 1.0
 * @package Test{NAMESPACE_SLASH}
 * @category Test
 */
class {NAME_UPPER} {

    /**
     * Point d'entrée pour le lancement des tests
     * 
     * @access public
     * @return void
     */
    function __construct() {
        
    }

}

?>