<?php
namespace Test{NAMESPACE_SLASH};
use Kernel\Testing;



// Classe de test Utilisateur
class {NAME_UPPER} {

    /**
     * Lancement des tests
     */
    static function run() {
        
    }

}

?>