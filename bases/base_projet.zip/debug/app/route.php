<?php
use Kernel\Router as r;
use Controler as c;



// r::notfound('');
// r::default('');
// r::add('', c\::class);



?>