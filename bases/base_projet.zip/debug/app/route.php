<?php
use Kernel\Router as r;
use Controler as c;



// r::notfound('404');
// r::default('accueil');
// r::add('accueil', c\Accueil::class);

?>