
class Panneau {

    /**
     * Constructeur
     */
    constructor() {
    }

}

let panneau = new Panneau();