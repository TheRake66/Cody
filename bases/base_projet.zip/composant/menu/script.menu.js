
class Menu {

    /**
     * Constructeur
     */
    constructor() {
    }

}

let menu = new Menu();