
class Accueil {

    /**
     * Constructeur
     */
	constructor() {
	}

};

let accueil = new Accueil();