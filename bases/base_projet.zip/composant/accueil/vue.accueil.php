<!-- ================================================== -->
<!-- Creation de la page d'accueil -->
<main>
    <p>Bienvenue sur {PROJECT_NAME} !</p>
</main>
<!-- ================================================== -->



<!-- ================================================== -->
<!-- Inclusion des fichiers -->
<link rel="stylesheet/less" type="text/css" href="composant/accueil/style.accueil.less">
<script type='text/javascript' src='composant/accueil/script.accueil.js'></script>
<!-- ================================================== -->
