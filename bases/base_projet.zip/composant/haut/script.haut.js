
class Haut {

    /**
     * Constructeur
     */
    constructor() {
    }

}

let haut = new Haut();