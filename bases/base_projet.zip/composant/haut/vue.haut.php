<!-- ================================================== -->
<!-- Creation du header -->
<header>
	<div>
		<img src="image/vector.svg">
		<h1>Cody</h1>
	</div>
</header>
<!-- ================================================== -->



<!-- ================================================== -->
<!-- Inclusion des fichiers -->
<link rel="stylesheet/less" type="text/css" href="composant/haut/style.haut.less">
<script type='text/javascript' src='composant/haut/script.haut.js'></script>
<!-- ================================================== -->