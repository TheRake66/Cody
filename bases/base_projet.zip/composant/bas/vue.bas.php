<!-- ================================================== -->
<!-- Creation du footer -->

<footer>
    
</footer>

<!-- ================================================== -->



<!-- ================================================== -->
<!-- Inclusion des fichiers -->
<link rel="stylesheet/less" type="text/css" href="composant/bas/style.bas.less">
<script type='text/javascript' src='composant/bas/script.bas.js'></script>
<!-- ================================================== -->
