<!-- ================================================== -->
<!-- Creation du footer -->
<footer>
Copyright © 2021 - Thibault BUSTOS (TheRake66)
</footer>
<!-- ================================================== -->



<!-- ================================================== -->
<!-- Inclusion des fichiers -->
<link rel="stylesheet/less" type="text/css" href="composant/bas/style.bas.less">
<script type='text/javascript' src='composant/bas/script.bas.js'></script>
<!-- ================================================== -->
