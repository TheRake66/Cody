
class Bas {

    /**
     * Constructeur
     */
    constructor() {
    }

}

let bas = new Bas();