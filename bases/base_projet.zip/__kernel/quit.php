<?php
ob_flush();
use Kernel as k;



// Affiche le superviseur
k\Suppervisor::showSuppervisor();

?>