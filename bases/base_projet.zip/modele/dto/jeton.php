<?php

namespace Modele;
use Modele\Reflect\Hydrate;



class Jeton {

    use Hydrate;
	public $utilisateurId;
	public $valeur;
	public $dateExpiration;

}

?>