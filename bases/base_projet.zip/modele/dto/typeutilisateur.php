<?php

namespace Modele;
use Modele\Reflect\Hydrate;



class TypeUtilisateur {

    use Hydrate;
	public $codeTypeUtilisateur;
	public $libelle;

}

?>