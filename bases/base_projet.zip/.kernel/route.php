<?php
use Kernel\URL\Router as r;
use Controller as c;
use API as a;


/*
r::notfound('/');
r::default('/');
r::add('/', c\::class);
/*

/*
r::add('/api/', a\::class);
r::add('/api/{id}', a\::class);
*/


?>