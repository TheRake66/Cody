<?php
use Kernel\IO\Router as r;
use Controler as c;
use API as a;


/*
r::notfound('/');
r::default('/');
r::add('/', c\::class);

r::add('/', a\::class);
*/


?>