<?php
use Kernel as k;



// Affiche le superviseur
k\Suppervisor::showSuppervisor();



ob_flush();
?>