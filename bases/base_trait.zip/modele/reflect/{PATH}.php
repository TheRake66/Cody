<?php

namespace Modele\Reflect{NAMESPACE_SLASH};



trait {NAME_UPPER} {
    
    
}

?>