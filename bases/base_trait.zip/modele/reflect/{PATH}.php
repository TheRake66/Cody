<?php
// Trait {NAME_UPPER}
namespace Modele\Reflect{NAMESPACE_SLASH};



trait {NAME_UPPER} {
    
}

?>