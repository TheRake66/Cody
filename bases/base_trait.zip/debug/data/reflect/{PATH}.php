<?php
namespace Model\Reflect{NAMESPACE_SLASH};



/**
 * Trait {NAME_UPPER}.
 * 
 * @author {USER_NAME}
 * @version 1.0
 * @package Model\Reflect{NAMESPACE_SLASH}
 * @category Trait script
 */
trait {NAME_UPPER} {
    
}

?>