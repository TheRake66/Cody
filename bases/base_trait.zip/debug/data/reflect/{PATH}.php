<?php
namespace Model\Reflect{NAMESPACE_SLASH};



/**
 * Trait {NAME_UPPER}
 */
trait {NAME_UPPER} {
    
}

?>