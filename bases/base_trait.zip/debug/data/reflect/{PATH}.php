<?php
// Trait {NAME_UPPER}
namespace Model\Reflect{NAMESPACE_SLASH};



trait {NAME_UPPER} {
    
}

?>