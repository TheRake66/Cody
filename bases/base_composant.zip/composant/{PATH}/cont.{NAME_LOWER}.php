<?php
// Controleur de la page {NAME_UPPER}
namespace Controleur{NAMESPACE_SLASH};
use Kernel\Ajax;
use Kernel\Render;



class {NAME_UPPER} {

    /**
     * Constructeur
     */
    function __construct() {
        // Rendu de la vue
        Render::view($this);
    }

}

?>