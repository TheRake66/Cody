<?php
// Controleur de la page {NAME_UPPER}
namespace Controleur{NAMESPACE_SLASH};



class {NAME_UPPER} {

    /**
     * Constructeur
     */
    function __construct() {
        // Appel de la vue
        include 'composant/{PATH}/vue.{NAME_LOWER}.php';
    }

}

?>