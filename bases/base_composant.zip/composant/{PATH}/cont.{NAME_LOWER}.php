<?php

namespace Controleur{NAMESPACE_SLASH};



class {NAME_UPPER} {

    /**
     * Constructeur
     */
    function __construct() {
    }


    /**
     * Destructeur
     */
    function __destruct() {
        include 'composant/{PATH}/vue.{NAME_LOWER}.php';
    }

}

?>