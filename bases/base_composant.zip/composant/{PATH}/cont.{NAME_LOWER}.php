<?php
namespace Controleur{NAMESPACE_SLASH};
use Kernel\Ajax;
use Kernel\Render;



// Controleur de la page {NAME_UPPER}
class {NAME_UPPER} extends Render {

    /**
     * Constructeur
     */
    function __construct() {
        // Rendu de la vue
        $this->view();
    }

}

?>