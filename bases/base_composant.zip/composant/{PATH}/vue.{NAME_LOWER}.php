<!-- Creation de la page {NAME_UPPER} -->
<main>
	<p>La page {NAME_UPPER} fonctionne !</p>
</main>



<!-- Inclusion des fichiers -->
<link rel="stylesheet/less" type="text/css" href="composant/{PATH}/style.{NAME_LOWER}.less">
<script type='text/javascript' src='composant/{PATH}/script.{NAME_LOWER}.js'></script>
