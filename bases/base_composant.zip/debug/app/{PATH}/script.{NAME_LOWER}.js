import Attribute from '{BACK_PATH}../../../.kernel/js/html/attribute.js';
import DOM from '{BACK_PATH}../../../.kernel/js/html/dom.js';
import Find from '{BACK_PATH}../../../.kernel/js/html/find.js';
import Rest from '{BACK_PATH}../../../.kernel/js/communication/rest.js';
import Location from '{BACK_PATH}../../../.kernel/js/url/location.js';



/**
 * Script du composant {NAME_UPPER}
 * 
 * @author {USER_NAME}
 * @version 1.0
 * @category Script
 */
export default class {NAME_UPPER} {

    /**
     * Point d'entrée du script
     * 
     * @access public
     * @return {void}
     */
    constructor() {
        
    }

}