// Ajout du script de la page {NAME_UPPER}
export default class {NAME_UPPER} {

    /**
     * Constructeur
     */
    constructor() {
        
    }

}