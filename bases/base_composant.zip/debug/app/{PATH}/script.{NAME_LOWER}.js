// Ajout du script du composant {NAME_UPPER}
export default class {NAME_UPPER} {

    /**
     * Constructeur
     */
    constructor() {
        
    }

}