import Html from '{BACK_PATH}../../../html.js';
import Rest from '{BACK_PATH}../../../rest.js';
import Url from '{BACK_PATH}../../../url.js';



/**
 * Script du composant {NAME_UPPER}
 */
export default class {NAME_UPPER} {

    /**
     * Constructeur
     */
    constructor() {
        
    }

}