// Ajout du script de la page {NAME_UPPER}
class {NAME_UPPER} {

    /**
     * Constructeur
     */
    constructor() {
        
    }

}