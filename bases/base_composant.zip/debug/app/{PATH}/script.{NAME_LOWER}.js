import Html from '{BACK_PATH}../../../.kernel/js/html.js';
import Rest from '{BACK_PATH}../../../.kernel/js/rest.js';
import Url from '{BACK_PATH}../../../.kernel/js/url.js';



/**
 * Script du composant {NAME_UPPER}
 * 
 * @author {USER_NAME}
 * @version 1.0
 * @category Script
 */
export default class {NAME_UPPER} {

    /**
     * Point d'entrée du script
     * 
     * @access public
     * @return {void}
     */
    constructor() {
        
    }

}