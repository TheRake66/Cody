<?php
use Kernel\Html\Attribute;
use Kernel\Html\Builder;
use Kernel\Html\Output;
use Kernel\Convert;
use Kernel\Url;
?>



<!-- Vue du composant {NAME_UPPER}  -->
<{FULL_DASH}>
	<p>Le composant {NAME_UPPER} fonctionne !</p>
</{FULL_DASH}>