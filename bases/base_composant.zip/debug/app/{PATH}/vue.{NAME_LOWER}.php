<?php
use Kernel\Html;
use Kernel\Convert;
use Kernel\Url;
?>



<!-- Vue du composant {NAME_UPPER}  -->
<{FULL_DASH}>
	<p>Le composant {NAME_UPPER} fonctionne !</p>
</{FULL_DASH}>