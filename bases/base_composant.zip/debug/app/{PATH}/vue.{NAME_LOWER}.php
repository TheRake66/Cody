<?php
use Kernel\Html;
use Kernel\Url;
use Kernel\Convert;
?>



<!-- Creation de la page {NAME_UPPER}  -->
<main>
	<p>La page {NAME_UPPER} fonctionne !</p>
</main>