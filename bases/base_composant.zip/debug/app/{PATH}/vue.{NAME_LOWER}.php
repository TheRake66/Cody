<?php
use Kernel\Html;
use Kernel\Url;
use Kernel\Convert;
?>



<!-- Creation du composant {NAME_UPPER}  -->
<{NAME_LOWER}>
	<p>Le composant {NAME_UPPER} fonctionne !</p>
</{NAME_LOWER}>