<?php
use Kernel\Html;
use Kernel\Url;
use Kernel\Convert;
?>



<!-- Creation du composant {NAME_UPPER}  -->
<{FULL_DASH}>
	<p>Le composant {NAME_UPPER} fonctionne !</p>
</{FULL_DASH}>