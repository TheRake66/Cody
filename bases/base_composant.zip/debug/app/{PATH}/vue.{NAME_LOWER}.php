<!-- Vue du composant {NAME_UPPER}  -->
<{FULL_DASH}>
	<p>Le composant {NAME_UPPER} fonctionne !</p>
</{FULL_DASH}>