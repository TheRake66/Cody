<?php
use Kernel\Security\Vulnerability\XSS;
use Kernel\Security\Vulnerability\CSRF;
use Kernel\Html\Attribute;
use Kernel\Html\Builder;
use Kernel\Html\Output;
use Kernel\Convert\Encoded;
use Kernel\Convert\Number;
use Kernel\URL\Location;
?>



<!-- 
Vue du composant {NAME_UPPER} 
Author: {USER_NAME}
Version: 1.0
 -->
<{FULL_DASH}>
	<p>Le composant {NAME_UPPER} fonctionne !</p>
</{FULL_DASH}>