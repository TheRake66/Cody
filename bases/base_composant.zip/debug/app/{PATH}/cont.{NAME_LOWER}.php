<?php
namespace Controler{NAMESPACE_SLASH};
use Kernel\Render;



/**
 * Controleur du composant {NAME_UPPER}
 */
class {NAME_UPPER} {

    /**
     * Constructeur
     */
    function __construct() {
        // Rendu de la vue
        Render::display();
    }

}

?>