<?php
namespace Controler{NAMESPACE_SLASH};
use Kernel\DataBase\Crud\Factory;
use Kernel\Security\Validation;
use Kernel\Security\Vulnerability;
use Kernel\Rest;
use Kernel\Render;



/**
 * Controleur du composant {NAME_UPPER}
 */
class {NAME_UPPER} {

    /**
     * Constructeur
     */
    function __construct() {
        // Rendu de la vue
        Render::view();
    }

}

?>