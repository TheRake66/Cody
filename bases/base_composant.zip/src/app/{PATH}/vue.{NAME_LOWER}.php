<!-- Creation de la page {NAME_UPPER}  -->
<?php
use Kernel\Html;
use Kernel\Url;
use Kernel\Convert;
?>



<main>
	<p>La page {NAME_UPPER} fonctionne !</p>
</main>