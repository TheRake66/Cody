<?php
namespace API{NAMESPACE_SLASH};
use Kernel\DataBase\Factory\Crud;
use Kernel\Security\Vulnerability\XSS;
use Kernel\Security\Vulnerability\CSRF;
use Kernel\Security\Validation;



/**
 * Module d'API {NAME_UPPER}
 * 
 * @author {USER_NAME}
 * @version 1.0
 * @package API{NAMESPACE_SLASH}
 * @category API
 */
class {NAME_UPPER} {

}

?>