<?php
// Classe DTO {NAME_UPPER}
namespace Modele\dto{NAMESPACE_SLASH};
use Kernel\Reflect\Hydrate;



class {NAME_UPPER} {

    use Hydrate;


    const PRIMARY = [

    ];

    
    function __construct() {
        
    }
	
}

?>