<?php

namespace Modele\dto{NAMESPACE_SLASH};
use Modele\Reflect\Hydrate;



class {NAME_UPPER} {

    use Hydrate;
	public $id{NAME_UPPER};
	
}

?>