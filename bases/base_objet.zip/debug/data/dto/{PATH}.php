<?php
namespace Model\dto{NAMESPACE_SLASH};
use Kernel\Reflect\Hydrate;



// Classe DTO {NAME_UPPER}
class {NAME_UPPER} {

    /**
     * Traits et proprietes
     */
    use Hydrate;


    /**
     * Liste des cles primaires
     */
    const PRIMARY = [

    ];
	

    /**
     * Constructeur
     */
    function __construct() {
        
    }
	
}

?>