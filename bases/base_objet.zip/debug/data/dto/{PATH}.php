<?php
namespace Model\dto{NAMESPACE_SLASH};



/**
 * Classe DTO {NAME_UPPER}
 */
class {NAME_UPPER} {

    /**
     * @var string La base de donnees
     */
    const DATABASE = '';

    /**
     * @var string|array La ou les cles primaires
     */
    const PRIMARY = '';
    

    /**
     * Proprietes
     */
	

    /**
     * Constructeur
     */
    function __construct() {
        
    }
	
}

?>