<?php
namespace Model\dto{NAMESPACE_SLASH};



/**
 * Classe DTO {NAME_UPPER}
 */
class {NAME_UPPER} {

    /**
     * @var mixed Les proprietes
     */
	

    /**
     * Constructeur
     */
    function __construct() {
        
    }
	
}

?>