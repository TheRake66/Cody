<?php

namespace Model\Dto{NAMESPACE_SLASH};

use Kernel\DataBase\Factory\Crud;



/**
 * Classe DTO {NAME_UPPER}.
 * 
 * @author {USER_NAME}
 * @version 1.0
 * @package Model\Dto{NAMESPACE_SLASH}
 * @category DTO Class (Data Transfer Object)
 */
class {NAME_UPPER} extends Crud {

    /**
     * @var mixed Les propriétés de l'objet.
     */
    

    /**
     * Constructeur de la classe.
     * 
     * @access public
     * @return void
     */
    function __construct() {
        
    }
	
}

?>