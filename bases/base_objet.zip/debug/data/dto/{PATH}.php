<?php
namespace Model\dto{NAMESPACE_SLASH};



/**
 * Classe DTO {NAME_UPPER}
 */
class {NAME_UPPER} {

    /**
     * Proprietes
     */


    /**
     * Liste des cles primaires
     */
    const PRIMARY = [

    ];
	

    /**
     * Constructeur
     */
    function __construct() {
        
    }
	
}

?>