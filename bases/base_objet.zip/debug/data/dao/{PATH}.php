<?php
namespace Model\dao{NAMESPACE_SLASH};
use Kernel\DataBase\Toogle;
use Kernel\DataBase\Transaction;
use Kernel\DataBase\Query;
use Model\dto{NAMESPACE_SLASH}\{NAME_UPPER} as dto;



/**
 * Classe DAO {NAME_UPPER}
 */
class {NAME_UPPER} {

}

?>