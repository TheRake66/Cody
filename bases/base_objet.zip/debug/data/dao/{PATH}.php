<?php
namespace Model\Dao{NAMESPACE_SLASH};

use Kernel\DataBase\Toogle;
use Kernel\DataBase\Transaction;
use Kernel\DataBase\Query;
use Model\Dto{NAMESPACE_SLASH}\{NAME_UPPER} as Dto;



/**
 * Classe DAO {NAME_UPPER}
 * 
 * @author {USER_NAME}
 * @version 1.0
 * @package Model\Dao{NAMESPACE_SLASH}
 * @category DAO (Data Access Object)
 */
class {NAME_UPPER} {

}

?>