<?php
namespace Model\dao{NAMESPACE_SLASH};
use Kernel\DataBase;
use Model\dto{NAMESPACE_SLASH}\{NAME_UPPER} as dto;



// Classe DAO {NAME_UPPER}
class {NAME_UPPER} {

}

?>