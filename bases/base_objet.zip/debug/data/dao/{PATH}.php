<?php
namespace Model\DAO{NAMESPACE_SLASH};

use Kernel\DataBase\Toogle;
use Kernel\DataBase\Transaction;
use Kernel\DataBase\Query;
use Model\DTO{NAMESPACE_SLASH}\{NAME_UPPER} as DTO;



/**
 * Classe DAO {NAME_UPPER}
 * 
 * @author {USER_NAME}
 * @version 1.0
 * @package Model\DAO{NAMESPACE_SLASH}
 * @category DAO (Data Access Object)
 */
class {NAME_UPPER} {

}

?>