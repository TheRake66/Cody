<?php
// Classe DAO {NAME_UPPER}
namespace Model\dao{NAMESPACE_SLASH};
use Kernel\DataBase;
use Model\dto{NAMESPACE_SLASH}\{NAME_UPPER} as dto;



class {NAME_UPPER} {

}

?>