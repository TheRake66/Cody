<?php
namespace Librairy{NAMESPACE_SLASH};
echo Html::importStyle('debug/lib/less/{PATH}.less');
echo Html::importScript('debug/lib/js/{PATH}.js');



// Librairie {NAME_UPPER}
class {NAME_UPPER} {

    /**
     * Constructeur
     */
    function __construct() {

    }
    
}

?>