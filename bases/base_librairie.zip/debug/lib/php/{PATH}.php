<?php
namespace Librairy{NAMESPACE_SLASH};



/**
 * Librairie {NAME_UPPER}
 * 
 * @author {USER_NAME}
 * @version 1.0
 * @package Librairy{NAMESPACE_SLASH}
 * @category Librairie
 */
class {NAME_UPPER} {

    /**
     * Point d'entrée de la librairie
     * 
     * @access public
     * @return void
     */
    function __construct() {

    }
    
}

?>