<?php
namespace Librairy{NAMESPACE_SLASH};



/**
 * Librairie {NAME_UPPER}
 */
class {NAME_UPPER} {

    /**
     * Constructeur
     */
    function __construct() {

    }
    
}

?>