// Librairie {NAME_UPPER}
class {NAME_UPPER} {

    /**
     * Constructeur
     */
    constructor() {
        
    }

}

let {NAME_LOWER} = new {NAME_UPPER}();