<?php

namespace Librairie{NAMESPACE_SLASH};



class {NAME_UPPER} {

    /**
     * Constructeur
     */
    function __construct() {
    }
   

    /**
     * Destructeur
     */
    function __destruct() {
    }
    
}

?>