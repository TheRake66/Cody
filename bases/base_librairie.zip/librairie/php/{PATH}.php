<?php
// Librairie {NAME_UPPER}
namespace Librairie{NAMESPACE_SLASH};



class {NAME_UPPER} {

    /**
     * Constructeur
     */
    function __construct() {
    }
   

    /**
     * Destructeur
     */
    function __destruct() {
    }
    
}

?>

<!-- Inclusion des fichiers -->
<link rel="stylesheet/less" type="text/css" href="librairie/less/{PATH}.less">
<script type='text/javascript' src='librairie/js/{PATH}.js'></script>